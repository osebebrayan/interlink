experiment coding - results of the mean of multiple experiments
